<?php
include 'config.php';
$npm = $_GET['npm'];
$data = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM mahasiswa WHERE npm='$npm'"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama    = $_POST['nama'];
    $jurusan = $_POST['jurusan'];
    $alamat  = $_POST['alamat'];

    mysqli_query($conn, "UPDATE mahasiswa SET nama='$nama', jurusan='$jurusan', alamat='$alamat' WHERE npm='$npm'");
    header("Location: mahasiswa.php");
}
?>
<link rel="stylesheet" href="style.css">
<form method="post">
    <h3>Edit Mahasiswa</h3>
    NPM: <b><?= $data['npm'] ?></b><br>
    Nama: <input type="text" name="nama" value="<?= $data['nama'] ?>"><br>
    Jurusan: 
    <select name="jurusan">
        <option <?= $data['jurusan'] == 'Teknik Informatika' ? 'selected' : '' ?>>Teknik Informatika</option>
        <option <?= $data['jurusan'] == 'Sistem Operasi' ? 'selected' : '' ?>>Sistem Operasi</option>
    </select><br>
    Alamat: <textarea name="alamat"><?= $data['alamat'] ?></textarea><br>
    <button type="submit">Update</button>
</form>
