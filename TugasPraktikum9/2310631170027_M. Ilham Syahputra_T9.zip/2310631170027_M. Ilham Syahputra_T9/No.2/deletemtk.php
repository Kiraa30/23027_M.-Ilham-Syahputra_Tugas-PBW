<?php
include 'config.php';
$kodemk = $_GET['kodemk'];
mysqli_query($conn, "DELETE FROM matakuliah WHERE kodemk='$kodemk'");
header("location:matakuliah.php");
?>
