<?php
include 'config.php';
$kodemk = $_GET['kodemk'];
$data = mysqli_query($conn, "SELECT * FROM matakuliah WHERE kodemk='$kodemk'");
$d = mysqli_fetch_array($data);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $sks = $_POST['jumlah_sks'];
    mysqli_query($conn, "UPDATE matakuliah SET nama='$nama', jumlah_sks='$sks' WHERE kodemk='$kodemk'");
    header("location:matakuliah.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Mata Kuliah</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Edit Mata Kuliah</h2>
<form method="post">
    <label>Kode MK:</label>
    <input type="text" value="<?= $d['kodemk'] ?>" disabled>

    <label>Nama:</label>
    <input type="text" name="nama" value="<?= $d['nama'] ?>" required>

    <label>Jumlah SKS:</label>
    <input type="text" name="jumlah_sks" value="<?= $d['jumlah_sks'] ?>" required>

    <button type="submit">Simpan Perubahan</button>
</form>
</body>
</html>
