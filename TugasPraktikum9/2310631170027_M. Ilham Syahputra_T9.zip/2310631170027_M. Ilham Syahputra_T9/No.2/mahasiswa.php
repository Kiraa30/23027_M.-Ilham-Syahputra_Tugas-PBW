<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2 style="text-align:center;">Data Mahasiswa</h2>
<div style="text-align:center; margin-bottom: 20px;">
    <a href="mahasiswa.php"><button>Data Mahasiswa</button></a>
    <a href="matakuliah.php"><button>Data Mata Kuliah</button></a>
    <a href="krs.php"><button>Data KRS</button></a>
</div>

<br>
<a href="tambah.php">Tambah Mahasiswa</a><br><br>

<table>
    <tr>
        <th>NPM</th>
        <th>Nama</th>
        <th>Jurusan</th>
        <th>Alamat</th>
        <th>Aksi</th>
    </tr>
    <?php
    $data = mysqli_query($conn, "SELECT * FROM mahasiswa");
    while($row = mysqli_fetch_array($data)) {
        echo "<tr>
                <td>{$row['npm']}</td>
                <td>{$row['nama']}</td>
                <td>{$row['jurusan']}</td>
                <td>{$row['alamat']}</td>
                <td>
                    <a href='editmhs.php?npm={$row['npm']}'>Edit</a> |
                    <a href='deletemhs.php?npm={$row['npm']}' onclick=\"return confirm('Yakin hapus?')\">Hapus</a>
                </td>
              </tr>";
    }
    ?>
</table>
</body>
</html>
