<?php
include 'config.php';
$npm = $_GET['npm'];

// Hapus semua data di krs yang terkait dengan mahasiswa ini
mysqli_query($conn, "DELETE FROM krs WHERE mahasiswa_npm='$npm'");

// Baru hapus dari tabel mahasiswa
mysqli_query($conn, "DELETE FROM mahasiswa WHERE npm='$npm'");

header("Location: mahasiswa.php");
?>
