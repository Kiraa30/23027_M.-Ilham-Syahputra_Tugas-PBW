<?php
include 'config.php';

if (!isset($_GET['hapus'])) {
    echo "ID tidak tersedia.";
    exit;
}

$id = $_GET['hapus'];

mysqli_query($conn, "DELETE FROM krs WHERE id='$id'");

header("Location: krs.php");
?>
