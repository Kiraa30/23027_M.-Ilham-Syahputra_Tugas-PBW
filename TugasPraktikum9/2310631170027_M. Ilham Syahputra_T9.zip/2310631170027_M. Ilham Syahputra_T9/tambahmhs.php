<?php
// Proses form saat tombol disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $npm = $_POST['npm'];
    $nama = $_POST['nama'];
    $jurusan = $_POST['jurusan'];
    $alamat = $_POST['alamat'];

    $query = "INSERT INTO mahasiswa (npm, nama, jurusan, alamat) 
              VALUES ('$npm', '$nama', '$jurusan', '$alamat')";

    if (mysqli_query($conn, $query)) {
        header("Location: matakuliah.php");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Data Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Tambah Data Mahasiswa</h2>
    <form method="post">
        <label for="npm">NPM:</label>
        <input type="text" name="npm" id="npm" required>

        <label for="nama">Nama:</label>
        <input type="text" name="nama" id="nama" required>

        <label for="jurusan">Jurusan:</label>
        <select name="jurusan" id="jurusan">
            <option value="Teknik Informatika">Teknik Informatika</option>
            <option value="Sistem Operasi">Sistem Operasi</option>
        </select>

        <label for="alamat">Alamat:</label>
        <textarea id="alamat" name="alamat" rows="4"></textarea>

        <button type="submit">Simpan</button>
        <a href="mahasiswa.php" class="back-button">Kembali</a>
    </form>
</body>
</html>
