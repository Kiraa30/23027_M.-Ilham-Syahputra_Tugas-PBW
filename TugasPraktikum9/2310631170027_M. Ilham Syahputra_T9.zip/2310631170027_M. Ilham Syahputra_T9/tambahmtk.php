<?php
include 'config.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kodemk = $_POST['kodemk'];
    $nama = $_POST['nama'];
    $sks = $_POST['jumlah_sks'];

    mysqli_query($conn, "INSERT INTO matakuliah VALUES('$kodemk', '$nama', '$sks')");
    header("location:matakuliah.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Mata Kuliah</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Tambah Mata Kuliah</h2>
<form method="post">
    <label>Kode MK:</label>
    <input type="text" name="kodemk" required>

    <label>Nama:</label>
    <input type="text" name="nama" required>

    <label>Jumlah SKS:</label>
    <input type="text" name="jumlah_sks" required>

    <button type="submit">Simpan</button>
</form>
</body>
</html>
