<?php include 'config.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Data KRS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2 style="text-align:center;">Data KRS</h2>

<div style="text-align:center; margin-bottom: 20px;">
    <a href="mahasiswa.php"><button>Data Mahasiswa</button></a>
    <a href="matakuliah.php"><button>Data Mata Kuliah</button></a>
    <a href="krs.php"><button>Data KRS</button></a>
</div>

    <br>
    <a href="tambahkrs.php" class="button">Tambah KRS</a>
    <br><br>

    <table>
        <tr>
            <th>No</th>
            <th>NPM</th>
            <th>Nama Mahasiswa</th>
            <th>Kode MK</th>
            <th>Nama Mata Kuliah</th>
            <th>SKS</th>
            <th>Aksi</th>
        </tr>

        <?php
        $no = 1;
        $query = "
            SELECT k.id, m.npm, m.nama AS nama_mhs, mk.kodemk, mk.nama AS nama_mk, mk.jumlah_sks
            FROM krs k
            JOIN mahasiswa m ON k.mahasiswa_npm = m.npm
            JOIN matakuliah mk ON k.matakuliah_kodemk = mk.kodemk
        ";
        $result = mysqli_query($conn, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$no}</td>
                    <td>{$row['npm']}</td>
                    <td>{$row['nama_mhs']}</td>
                    <td>{$row['kodemk']}</td>
                    <td>{$row['nama_mk']}</td>
                    <td>{$row['jumlah_sks']}</td>
                    <td>
                        <a href='editkrs.php?id={$row['id']}' class='edit'>Edit</a> |
                        <a href='deletekrs.php?hapus={$row['id']}' onclick=\"return confirm('Hapus data ini?')\" class='hapus'>Hapus</a>
                    </td>
                  </tr>";
            $no++;
        }
        ?>
    </table>
</body>
</html>