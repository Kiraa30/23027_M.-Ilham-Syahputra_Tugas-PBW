<?php include 'config.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Mata Kuliah</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2 style="text-align:center;">Data Mata Kuliah</h2>
<div style="text-align:center; margin-bottom: 20px;">
    <a href="mahasiswa.php"><button>Data Mahasiswa</button></a>
    <a href="matakuliah.php"><button>Data Mata Kuliah</button></a>
    <a href="krs.php"><button>Data KRS</button></a>
</div>

<br>
    <a href="tambahmtk.php" class="button">Tambah Mata Kuliah</a>
    <br><br>

<table>
    <tr>
        <th>No</th>
        <th>Kode MK</th>
        <th>Nama Mata Kuliah</th>
        <th>Jumlah SKS</th>
        <th>Aksi</th>
    </tr>

    <?php
    $no = 1;
    $query = mysqli_query($conn, "SELECT * FROM matakuliah");

    while ($data = mysqli_fetch_array($query)) {
        echo "<tr>
                <td>{$no}</td>
                <td>{$data['kodemk']}</td>
                <td>{$data['nama']}</td>
                <td>{$data['jumlah_sks']}</td>
                <td>
                    <a href='editmtk.php?kodemk={$data['kodemk']}'>Edit</a> |
                    <a href='deletemtk.php?kodemk={$data['kodemk']}' onclick=\"return confirm('Yakin ingin menghapus?')\">Hapus</a>
                </td>
              </tr>";
        $no++;
    }
    ?>
</table>

</body>
</html>