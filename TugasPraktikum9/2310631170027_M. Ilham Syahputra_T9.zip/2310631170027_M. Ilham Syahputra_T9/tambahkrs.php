<?php
include 'config.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $npm = $_POST['npm'];
    $kodemk = $_POST['kodemk'];
    mysqli_query($conn, "INSERT INTO krs (mahasiswa_npm, matakuliah_kodemk) VALUES('$npm', '$kodemk')");
    header("location:krs.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah KRS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Tambah KRS</h2>
<form method="post">
    <label>Mahasiswa:</label>
    <select name="npm" required>
        <?php
        $mhs = mysqli_query($conn, "SELECT * FROM mahasiswa");
        while ($row = mysqli_fetch_array($mhs)) {
            echo "<option value='{$row['npm']}'>{$row['nama']}</option>";
        }
        ?>
    </select>

    <label>Mata Kuliah:</label>
    <select name="kodemk" required>
        <?php
        $mk = mysqli_query($conn, "SELECT * FROM matakuliah");
        while ($row = mysqli_fetch_array($mk)) {
            echo "<option value='{$row['kodemk']}'>{$row['nama']}</option>";
        }
        ?>
    </select>

    <button type="submit">Simpan</button>
</form>
</body>
</html>
