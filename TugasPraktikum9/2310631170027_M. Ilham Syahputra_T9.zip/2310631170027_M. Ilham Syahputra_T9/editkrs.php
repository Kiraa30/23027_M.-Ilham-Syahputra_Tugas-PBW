<?php
include 'config.php';
$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM krs WHERE id='$id'");
$d = mysqli_fetch_array($data);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $npm = $_POST['npm'];
    $kodemk = $_POST['kodemk'];
    mysqli_query($conn, "UPDATE krs SET mahasiswa_npm='$npm', matakuliah_kodemk='$kodemk' WHERE id='$id'");
    header("location:krs.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit KRS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Edit KRS</h2>
<form method="post">
    <label>Mahasiswa:</label>
    <select name="npm">
        <?php
        $mhs = mysqli_query($conn, "SELECT * FROM mahasiswa");
        while ($row = mysqli_fetch_array($mhs)) {
            $selected = $row['npm'] == $d['mahasiswa_npm'] ? 'selected' : '';
            echo "<option value='{$row['npm']}' $selected>{$row['nama']}</option>";
        }
        ?>
    </select>

    <label>Mata Kuliah:</label>
    <select name="kodemk">
        <?php
        $mk = mysqli_query($conn, "SELECT * FROM matakuliah");
        while ($row = mysqli_fetch_array($mk)) {
            $selected = $row['kodemk'] == $d['matakuliah_kodemk'] ? 'selected' : '';
            echo "<option value='{$row['kodemk']}' $selected>{$row['nama']}</option>";
        }
        ?>
    </select>

    <button type="submit">Simpan Perubahan</button>
</form>
</body>
</html>
