<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Rute Penerbangan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .rute-box {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 20px;
            background-color: #fdfdfd;
        }
        .rute-box h3 {
            margin-top: 0;
            font-size: 18px;
        }
        .detail-group div {
            margin-bottom: 6px;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="container" data-aos="fade-up">
    <h2>Daftar Rute Penerbangan</h2>

    <?php
    $file = 'data_rute.txt';
    if (file_exists($file)) {
        $data_rute = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        if (count($data_rute) > 0) {
            foreach ($data_rute as $baris) {
                $kolom = explode(' | ', $baris);
                if (count($kolom) >= 9) {
                    echo "<div class='rute-box'>";
                    echo "<h3>" . htmlspecialchars($kolom[2]) . "</h3>"; // Maskapai

                    echo "<div class='detail-group'>";
                    echo "<div><strong>No Penerbangan:</strong> " . htmlspecialchars($kolom[0]) . "</div>";
                    echo "<div><strong>Tanggal:</strong> " . htmlspecialchars($kolom[1]) . "</div>";
                    echo "<div><strong>Asal:</strong> " . htmlspecialchars($kolom[3]) . "</div>";
                    echo "<div><strong>Tujuan:</strong> " . htmlspecialchars($kolom[4]) . "</div>";
                    echo "<div><strong>Kelas:</strong> " . htmlspecialchars($kolom[5]) . "</div>";
                    echo "<div><strong>Harga Tiket:</strong> " . htmlspecialchars($kolom[6]) . "</div>";
                    echo "<div><strong>Pajak:</strong> " . htmlspecialchars($kolom[7]) . "</div>";
                    echo "<div><strong>Total Harga:</strong> " . htmlspecialchars($kolom[8]) . "</div>";
                    echo "</div>";

                    echo "<hr>";
                    echo "</div>";
                }
            }
        } else {
            echo "<p>Belum ada data penerbangan.</p>";
        }
    } else {
        echo "<p>Belum ada data penerbangan.</p>";
    }
    ?>

    <a href="form.php">Tambah Data Baru</a>
</div>

<!-- AOS Animation -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    duration: 1000,
    once: true
  });
</script>

</body>
</html>
