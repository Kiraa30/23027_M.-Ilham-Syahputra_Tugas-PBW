<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $maskapai = htmlspecialchars($_POST['maskapai']);
    $asal = htmlspecialchars($_POST['asal']);
    $tujuan = htmlspecialchars($_POST['tujuan']);
    $tanggal_input = htmlspecialchars($_POST['tanggal']);
    $kelas = htmlspecialchars($_POST['kelas']);
    $harga = (float) htmlspecialchars($_POST['harga']);

    // Format tanggal ke d-m-Y
    $tanggal = date('d-m-Y', strtotime($tanggal_input));

    // Pajak bandara asal
    $pajak_asal = 0;
    switch ($asal) {
        case "Soekarno Hatta":
            $pajak_asal = 65000;
            break;
        case "Husein Sastranegara":
            $pajak_asal = 50000;
            break;
        case "Abdul Rachman Saleh":
            $pajak_asal = 40000;
            break;
        case "Juanda":
            $pajak_asal = 30000;
            break;
        default:
            $pajak_asal = 0;
    }

    // Pajak bandara tujuan
    $pajak_tujuan = 0;
    switch ($tujuan) {
        case "Ngurah Rai":
            $pajak_tujuan = 85000;
            break;
        case "Hasanuddin":
            $pajak_tujuan = 70000;
            break;
        case "Inanwatan":
            $pajak_tujuan = 90000;
            break;
        case "Sultan Iskandar Muda":
            $pajak_tujuan = 60000;
            break;
        default:
            $pajak_tujuan = 0;
    }

    // Hitung total pajak dan total harga tiket
    $total_pajak = $pajak_asal + $pajak_tujuan;
    $total_harga = $harga + $total_pajak;

    // Generate nomor penerbangan
    $nomor = 'FL' . rand(1000, 9999);

    // Format data untuk disimpan
    $data = "$nomor | $tanggal | $maskapai | $asal | $tujuan | $kelas | Rp " . number_format($harga, 0, ',', '.') . " | Rp " . number_format($total_pajak, 0, ',', '.') . " | Rp " . number_format($total_harga, 0, ',', '.') . "\n";

    // Simpan ke file
    $file = 'data_rute.txt';
    file_put_contents($file, $data, FILE_APPEND | LOCK_EX);

    // Redirect ke daftar rute
    header("Location: daftar_rute.php");
    exit();
} else {
    echo "Akses tidak valid.";
}
?>
