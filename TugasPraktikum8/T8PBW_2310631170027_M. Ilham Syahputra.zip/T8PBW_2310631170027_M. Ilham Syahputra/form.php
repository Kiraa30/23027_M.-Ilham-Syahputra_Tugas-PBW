<?php
// Array bandara asal
$bandara_asal = ["Soekarno Hatta", "Husein Sastranegara", "Abdul Rachman Saleh", "Juanda"];
sort($bandara_asal);

// Array bandara tujuan
$bandara_tujuan = ["Ngurah Rai", "Hasanuddin", "Inanwatan", "Sultan Iskandar Muda"];
sort($bandara_tujuan);

// Array maskapai
$maskapai_list = ["Garuda Indonesia", "Lion Air", "Wings Air", "Citilink", "Batik Air", "Sriwijaya Air"];
sort($maskapai_list);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Rute Penerbangan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <!-- Flatpickr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>
<body>

<div class="container" data-aos="fade-up">
    <h2>Pendaftaran Rute Penerbangan</h2>
    <form action="proses.php" method="post">
        <label for="maskapai">Nama Maskapai:</label>
        <select id="maskapai" name="maskapai" required>
            <option value="">-- Pilih Maskapai --</option>
            <?php foreach ($maskapai_list as $maskapai) { ?>
                <option value="<?php echo $maskapai; ?>"><?php echo $maskapai; ?></option>
            <?php } ?>
        </select>

        <label for="asal">Bandara Asal:</label>
        <select id="asal" name="asal" required>
            <option value="">-- Pilih Bandara Asal --</option>
            <?php foreach ($bandara_asal as $asal) { ?>
                <option value="<?php echo $asal; ?>"><?php echo $asal; ?></option>
            <?php } ?>
        </select>

        <label for="tujuan">Bandara Tujuan:</label>
        <select id="tujuan" name="tujuan" required>
            <option value="">-- Pilih Bandara Tujuan --</option>
            <?php foreach ($bandara_tujuan as $tujuan) { ?>
                <option value="<?php echo $tujuan; ?>"><?php echo $tujuan; ?></option>
            <?php } ?>
        </select>

        <label for="tanggal">Tanggal Penerbangan:</label>
        <input type="text" id="tanggal" name="tanggal" placeholder="Pilih Tanggal" required readonly>

        <label for="kelas">Kelas Penerbangan:</label>
        <select id="kelas" name="kelas" required onchange="setHarga()">
            <option value="">-- Pilih Kelas --</option>
            <option value="Ekonomi">Ekonomi</option>
            <option value="Bisnis">Bisnis</option>
            <option value="First Class">First Class</option>
        </select>

        <label for="harga">Harga Tiket:</label>
        <input type="text" id="harga" name="harga" readonly required class="harga-input">

        <input type="submit" value="Daftar Penerbangan">
    </form>
    <a href="daftar_rute.php">Lihat Daftar Rute</a>
</div>

<!-- Script -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
AOS.init({
    duration: 1000,
    once: true
});

// Function untuk set harga tiket berdasarkan kelas
function setHarga() {
    const kelas = document.getElementById('kelas').value;
    const hargaInput = document.getElementById('harga');

    let harga = '';

    if (kelas === 'Ekonomi') {
        harga = 1000000;
    } else if (kelas === 'Bisnis') {
        harga = 2500000;
    } else if (kelas === 'First Class') {
        harga = 5000000;
    }

    hargaInput.classList.add('harga-anim');
    setTimeout(() => {
        hargaInput.value = harga;
        hargaInput.classList.remove('harga-anim');
    }, 300);
}

// Flatpickr dengan mencegah input manual
flatpickr("#tanggal", {
    dateFormat: "d-m-Y",
    altInput: true,
    altFormat: "F j, Y",
    allowInput: false // mencegah input manual
});
</script>

</body>
</html>
