// Smooth scrolling untuk anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    document.querySelector(this.getAttribute('href')).scrollIntoView({
      behavior: 'smooth'
    });
  });
});

// Animasi tombol CTA
const ctaButton = document.querySelector('.cta-button');
if (ctaButton) {
  ctaButton.addEventListener('mouseenter', () => {
    ctaButton.style.transform = 'scale(1.05)';
  });
  ctaButton.addEventListener('mouseleave', () => {
    ctaButton.style.transform = 'scale(1)';
  });
}
